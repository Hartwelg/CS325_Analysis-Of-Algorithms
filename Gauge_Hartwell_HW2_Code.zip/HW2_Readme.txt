badsort.cpp
- g++ badSort.cpp -o badSort -std=c++11
- ./badSort
badSortTime.cpp
- g++ badSortTime.cpp -o badSortTime -std=c++11
- ./badSortTime