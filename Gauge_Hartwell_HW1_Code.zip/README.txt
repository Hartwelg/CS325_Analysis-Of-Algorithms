insertsort.cpp
- g++ insertsort.cpp -o insertsort -std=c++11
- ./insertsort
mergesort.cpp
- g++ mergesort.cpp -o mergesort -std=c++11
- ./mergesort
insertTime.cpp
- g++ insertTime.cpp -o insertTime -std=c++11
- ./insertTime
mergeTime.cpp
- g++ mergeTime.cpp -o mergeTime -std=c++11
- ./mergeTime